<?php
session_start();
$upload_dir = 'uploads/';
$message = '';
$uploaded_file_path = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['file'])) {
    $file = $_FILES['file'];
    $filename = $file['name'];
    $tmp_name = $file['tmp_name'];
    
    // Simulating a "real" backend that forgets to check extensions
    // It might check file size or existence, but not the extension.
    
    if ($file['error'] === UPLOAD_ERR_OK) {
        $target_file = $upload_dir . basename($filename);
        
        // Simple collision avoidance (optional, but good for a real feel)
        // actually, let's keep it simple so the user knows the filename.
        // If we want to be very realistic, we might rename it, but then we need to tell the user the new name.
        // Let's just use the original name for simplicity in this level, or maybe prepend time() if we want to be fancy.
        // The requirement is "upload htm file to hit stored XSS".
        // If I rename it to a random hash, they might not know where it is unless I tell them.
        
        if (move_uploaded_file($tmp_name, $target_file)) {
            $message = "File uploaded successfully!";
            $uploaded_file_path = $target_file;
        } else {
            $message = "Upload failed.";
        }
    } else {
        $message = "Error uploading file.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Level 51 - Employee Portal</title>
    <style>
        :root {
            --primary-color: #4a90e2;
            --secondary-color: #f5f6fa;
            --text-color: #2c3e50;
            --border-radius: 8px;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #eef2f7;
            color: var(--text-color);
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
        
        .container {
            background-color: white;
            padding: 40px;
            border-radius: var(--border-radius);
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
            width: 100%;
            max-width: 500px;
        }
        
        h1 {
            color: var(--primary-color);
            text-align: center;
            margin-bottom: 30px;
            font-weight: 600;
        }
        
        .upload-area {
            border: 2px dashed #cbd5e0;
            border-radius: var(--border-radius);
            padding: 40px 20px;
            text-align: center;
            transition: all 0.3s ease;
            cursor: pointer;
            margin-bottom: 20px;
        }
        
        .upload-area:hover {
            border-color: var(--primary-color);
            background-color: rgba(74, 144, 226, 0.05);
        }
        
        .upload-icon {
            font-size: 48px;
            color: #cbd5e0;
            margin-bottom: 10px;
        }
        
        .btn {
            background-color: var(--primary-color);
            color: white;
            border: none;
            padding: 12px 24px;
            border-radius: var(--border-radius);
            cursor: pointer;
            width: 100%;
            font-size: 16px;
            font-weight: 500;
            transition: background-color 0.3s;
        }
        
        .btn:hover {
            background-color: #357abd;
        }
        
        .message {
            margin-top: 20px;
            padding: 15px;
            border-radius: var(--border-radius);
            text-align: center;
        }
        
        .success {
            background-color: #d4edda;
            color: #155724;
        }
        
        .error {
            background-color: #f8d7da;
            color: #721c24;
        }
        
        .file-link {
            display: block;
            margin-top: 10px;
            word-break: break-all;
            color: var(--primary-color);
            text-decoration: none;
        }
        
        .file-link:hover {
            text-decoration: underline;
        }
        
        /* Custom file input */
        input[type="file"] {
            display: none;
        }
        
        label {
            display: block;
            width: 100%;
            height: 100%;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Employee Document Portal</h1>
        <p style="text-align: center; color: #7f8c8d; margin-bottom: 30px;">
            Please upload your resume or personal documents.<br>
            <small>(Supported formats: PDF, DOCX, JPG...)</small>
        </p>
        
        <form action="" method="POST" enctype="multipart/form-data">
            <div class="upload-area" id="drop-zone">
                <label for="file-input">
                    <div class="upload-icon">📁</div>
                    <div id="file-label">Click to select a file</div>
                </label>
                <input type="file" name="file" id="file-input" required>
            </div>
            
            <button type="submit" class="btn">Upload Document</button>
        </form>
        
        <?php if ($message): ?>
            <div class="message <?php echo strpos($message, 'success') !== false ? 'success' : 'error'; ?>">
                <?php echo htmlspecialchars($message); ?>
                <?php if ($uploaded_file_path): ?>
                    <br>
                    <a href="<?php echo htmlspecialchars($uploaded_file_path); ?>" class="file-link" target="_blank">
                        View Uploaded File: <?php echo htmlspecialchars(basename($uploaded_file_path)); ?>
                    </a>
                <?php endif; ?>
            </div>
        <?php endif; ?>
        
        <div style="margin-top: 30px; text-align: center;">
            <a href="../index.php" style="color: #95a5a6; text-decoration: none; font-size: 14px;">&larr; Back to Levels</a>
        </div>
    </div>

    <script>
        const fileInput = document.getElementById('file-input');
        const fileLabel = document.getElementById('file-label');
        const dropZone = document.getElementById('drop-zone');

        fileInput.addEventListener('change', (e) => {
            if (e.target.files.length > 0) {
                fileLabel.textContent = e.target.files[0].name;
                dropZone.style.borderColor = '#4a90e2';
                dropZone.style.backgroundColor = 'rgba(74, 144, 226, 0.05)';
            }
        });
    </script>
</body>
</html>
