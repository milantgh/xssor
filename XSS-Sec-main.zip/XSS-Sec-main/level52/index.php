<?php
// Level 52: Filename XSS
// Vulnerability: The application renames the file for storage (safe) but echoes the ORIGINAL filename back to the user without escaping (vulnerable).

session_start();
$upload_dir = 'uploads/';
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['file'])) {
    $file = $_FILES['file'];
    $original_filename = $file['name']; // Vulnerable input
    $ext = pathinfo($original_filename, PATHINFO_EXTENSION);
    
    // Generate a safe random name for storage to bypass OS restrictions on special chars
    $new_filename = uniqid() . '.' . $ext;
    $target_file = $upload_dir . $new_filename;
    
    if ($file['error'] === UPLOAD_ERR_OK) {
        if (move_uploaded_file($file['tmp_name'], $target_file)) {
            // VULNERABILITY: Echoing $original_filename without htmlspecialchars
            // The developer thought: "I renamed the file on disk, so it's safe now."
            // But they forgot about the reflection in the success message.
            $message = "<div class='alert success'>
                            <div class='icon'>✓</div>
                            <div class='content'>
                                <div class='title'>Upload Complete</div>
                                <div class='text'>
                                    File has been securely stored.<br>
                                    <label style='display:block;margin-top:8px;font-size:11px;color:#636e72;'>Original Filename:</label>
                                    <input type='text' value='" . $original_filename . "' style='width:100%;padding:8px;border:1px solid #dfe6e9;border-radius:6px;margin-top:4px;color:#2d3436;' readonly>
                                </div>
                                <div class='meta'>System ID: " . $new_filename . "</div>
                            </div>
                        </div>";
        } else {
            // Even on failure, it might reflect
            $message = "<div class='alert error'>
                            <div class='icon'>✕</div>
                            <div class='content'>
                                <div class='title'>Upload Failed</div>
                                <div class='text'>Could not save <strong>" . htmlspecialchars($original_filename) . "</strong>.</div>
                            </div>
                        </div>";
        }
    } else {
        $message = "<div class='alert error'>
                        <div class='icon'>!</div>
                        <div class='content'>
                            <div class='title'>Error</div>
                            <div class='text'>Error uploading <strong>" . htmlspecialchars($original_filename) . "</strong>.</div>
                        </div>
                    </div>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Level 52 - Secure Cloud Storage</title>
    <style>
        :root {
            --bg-color: #f0f2f5;
            --card-bg: #ffffff;
            --primary: #6c5ce7;
            --primary-hover: #5b4cc4;
            --text-main: #2d3436;
            --text-sub: #636e72;
            --success: #00b894;
            --error: #d63031;
        }

        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background-color: var(--bg-color);
            color: var(--text-main);
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .container {
            width: 100%;
            max-width: 480px;
            padding: 20px;
        }

        .card {
            background: var(--card-bg);
            border-radius: 16px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.05);
            padding: 40px;
            text-align: center;
        }

        .logo {
            width: 64px;
            height: 64px;
            background: linear-gradient(135deg, #a29bfe, #6c5ce7);
            border-radius: 16px;
            margin: 0 auto 24px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 32px;
            box-shadow: 0 8px 16px rgba(108, 92, 231, 0.2);
        }

        h1 {
            font-size: 24px;
            font-weight: 700;
            margin: 0 0 8px;
            color: var(--text-main);
        }

        p {
            color: var(--text-sub);
            margin: 0 0 32px;
            line-height: 1.5;
        }

        .upload-box {
            border: 2px dashed #dfe6e9;
            border-radius: 12px;
            padding: 32px 20px;
            cursor: pointer;
            transition: all 0.3s ease;
            background: #fafafa;
            position: relative;
            overflow: hidden;
        }

        .upload-box:hover {
            border-color: var(--primary);
            background: #f4f3ff;
        }

        .upload-box input[type="file"] {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            opacity: 0;
            cursor: pointer;
        }

        .upload-icon {
            font-size: 40px;
            color: #b2bec3;
            margin-bottom: 12px;
            transition: color 0.3s;
        }

        .upload-box:hover .upload-icon {
            color: var(--primary);
        }

        .upload-text {
            font-weight: 500;
            color: var(--text-sub);
        }

        .btn {
            background-color: var(--primary);
            color: white;
            border: none;
            padding: 14px 28px;
            border-radius: 12px;
            font-size: 16px;
            font-weight: 600;
            margin-top: 24px;
            width: 100%;
            cursor: pointer;
            transition: transform 0.2s, box-shadow 0.2s;
        }

        .btn:hover {
            background-color: var(--primary-hover);
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(108, 92, 231, 0.3);
        }

        .alert {
            margin-top: 24px;
            padding: 16px;
            border-radius: 12px;
            display: flex;
            align-items: flex-start;
            text-align: left;
            animation: slideIn 0.4s ease-out;
        }

        @keyframes slideIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .alert.success {
            background-color: rgba(0, 184, 148, 0.1);
            border: 1px solid rgba(0, 184, 148, 0.2);
        }

        .alert.error {
            background-color: rgba(214, 48, 49, 0.1);
            border: 1px solid rgba(214, 48, 49, 0.2);
        }

        .alert .icon {
            margin-right: 12px;
            font-size: 20px;
            flex-shrink: 0;
        }

        .alert.success .icon { color: var(--success); }
        .alert.error .icon { color: var(--error); }

        .alert .content {
            flex-grow: 1;
        }

        .alert .title {
            font-weight: 700;
            margin-bottom: 4px;
            font-size: 14px;
        }
        
        .alert.success .title { color: #008f72; }
        .alert.error .title { color: #b71c1c; }

        .alert .text {
            font-size: 13px;
            color: var(--text-main);
            word-break: break-word;
        }

        .alert .meta {
            font-size: 11px;
            color: var(--text-sub);
            margin-top: 6px;
            font-family: monospace;
        }

        .back-link {
            display: inline-block;
            margin-top: 24px;
            color: var(--text-sub);
            text-decoration: none;
            font-size: 14px;
            transition: color 0.2s;
        }

        .back-link:hover {
            color: var(--text-main);
        }
        
        #file-name-display {
            margin-top: 10px;
            font-size: 13px;
            color: var(--primary);
            font-weight: 500;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="card">
            <div class="logo">☁️</div>
            <h1>SecureCloud</h1>
            <p>Upload your files to our secure encrypted storage.<br>We automatically rename files for security.</p>
            
            <form action="" method="POST" enctype="multipart/form-data">
                <div class="upload-box">
                    <input type="file" name="file" id="file-input" required>
                    <div class="upload-icon">⬆️</div>
                    <div class="upload-text">Drop files here or click to upload</div>
                    <div id="file-name-display"></div>
                </div>
                
                <button type="submit" class="btn">Upload to Cloud</button>
            </form>

            <?php echo $message; ?>
            
            <a href="../index.php" class="back-link">← Return to Levels</a>
        </div>
    </div>

    <script>
        const fileInput = document.getElementById('file-input');
        const fileNameDisplay = document.getElementById('file-name-display');
        const uploadText = document.querySelector('.upload-text');

        fileInput.addEventListener('change', (e) => {
            if (e.target.files.length > 0) {
                const name = e.target.files[0].name;
                fileNameDisplay.textContent = name;
                uploadText.style.display = 'none';
            }
        });
    </script>
</body>
</html>
